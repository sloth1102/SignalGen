import SwiftUI

@main
struct SignalGenApp: App {
    @StateObject private var settings = AppSettings()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
        }
        .commands {
            // Remove the default View menu additions (we don't touch Edit/File/Help)
            CommandGroup(replacing: .sidebar) { }

            CommandMenu("Misc") {
                Toggle("Show MHz / GHz Units", isOn: $settings.showAdvancedUnits)
                    .keyboardShortcut("u", modifiers: [.command, .shift])

                Divider()

                Toggle("Show Waveform Glow", isOn: $settings.showGlow)
                    .keyboardShortcut("g", modifiers: [.command, .shift])

                Divider()

                Toggle("Use Cosine Instead of Sine", isOn: $settings.useCosine)
                    .keyboardShortcut("c", modifiers: [.command, .shift])
            }
        }
    }
}
