import SwiftUI

struct WaveformView: View {
    var samples: [Float]
    var color: Color = .green
    var frequency: Double = 440.0
    var amplitude: Double = 0.5
    var windowSeconds: Double = 0.02
    var waveform: Waveform = .sine
    var showGlow: Bool = false

    private func buildWavePath(plotW: Double, plotH: Double, padLeft: Double, padTop: Double, midY: Double) -> Path {
        var path = Path()
        guard samples.count > 1 else { return path }

        let step = plotW / Double(max(samples.count - 1, 1))

        func yPos(_ sample: Float) -> Double {
            midY - Double(sample) * (plotH / 2) * 0.85
        }

        path.move(to: CGPoint(x: padLeft, y: yPos(samples[0])))

        // FIX: Use a tighter threshold and correct vertical-line direction
        // for sawtooth. The old code drew the vertical at prevX using the
        // new y, which caused it to skip or mis-draw the spike. Now we
        // draw the full vertical extent explicitly at the discontinuity x.
        let jumpThreshold = Float(amplitude) * 1.2   // must exceed 1 full peak-to-peak scaled amplitude

        for i in 1..<samples.count {
            let x    = padLeft + Double(i) * step
            let y    = yPos(samples[i])
            let prevY = yPos(samples[i - 1])
            let prevX = padLeft + Double(i - 1) * step

            if waveform.hasVerticalTransitions && abs(samples[i] - samples[i - 1]) > jumpThreshold {
                // Draw up to the end of the previous segment, then lift pen
                // and move to the start of the new segment — no connecting line
                // across the discontinuity (keeps sawtooth/square spikes clean).
                path.addLine(to: CGPoint(x: prevX, y: prevY))
                // Draw the vertical transition at the midpoint between samples
                let midX = (prevX + x) / 2.0
                path.addLine(to: CGPoint(x: midX, y: prevY))
                path.addLine(to: CGPoint(x: midX, y: y))
                path.addLine(to: CGPoint(x: x, y: y))
            } else {
                path.addLine(to: CGPoint(x: x, y: y))
            }
        }

        return path
    }

    var body: some View {
        GeometryReader { geo in
            let width = geo.size.width
            let height = geo.size.height

            let padLeft: Double = 44
            let padBottom: Double = 28
            let padTop: Double = 8
            let padRight: Double = 8

            let plotW = width - padLeft - padRight
            let plotH = height - padBottom - padTop
            let midY = padTop + plotH / 2

            let wavePath = buildWavePath(
                plotW: plotW,
                plotH: plotH,
                padLeft: padLeft,
                padTop: padTop,
                midY: midY
            )

            ZStack(alignment: .topLeading) {

                // Grid
                Path { path in
                    path.move(to: CGPoint(x: padLeft, y: midY))
                    path.addLine(to: CGPoint(x: padLeft + plotW, y: midY))
                    path.move(to: CGPoint(x: padLeft, y: padTop + plotH * 0.25))
                    path.addLine(to: CGPoint(x: padLeft + plotW, y: padTop + plotH * 0.25))
                    path.move(to: CGPoint(x: padLeft, y: padTop + plotH * 0.75))
                    path.addLine(to: CGPoint(x: padLeft + plotW, y: padTop + plotH * 0.75))
                    for i in 0...4 {
                        let x = padLeft + plotW * Double(i) / 4.0
                        path.move(to: CGPoint(x: x, y: padTop))
                        path.addLine(to: CGPoint(x: x, y: padTop + plotH))
                    }
                }
                .stroke(Color.white.opacity(0.08), lineWidth: 1)

                // Axes
                Path { path in
                    path.move(to: CGPoint(x: padLeft, y: padTop))
                    path.addLine(to: CGPoint(x: padLeft, y: padTop + plotH))
                    path.move(to: CGPoint(x: padLeft, y: padTop + plotH))
                    path.addLine(to: CGPoint(x: padLeft + plotW, y: padTop + plotH))
                }
                .stroke(Color.white.opacity(0.25), lineWidth: 1)

                if showGlow {
                    wavePath
                        .stroke(color.opacity(0.4), lineWidth: 6)
                        .blur(radius: 4)
                }

                wavePath
                    .stroke(color, lineWidth: 2)

                let ampStr     = String(format: "%.2f", amplitude)
                let halfAmpStr = String(format: "%.2f", amplitude / 2)

                Text("+\(ampStr)")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(.white.opacity(0.4))
                    .frame(width: padLeft - 4, alignment: .trailing)
                    .position(x: (padLeft - 4) / 2, y: padTop + plotH * 0.075)

                Text("+\(halfAmpStr)")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(.white.opacity(0.4))
                    .frame(width: padLeft - 4, alignment: .trailing)
                    .position(x: (padLeft - 4) / 2, y: padTop + plotH * 0.25)

                Text("0")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(.white.opacity(0.4))
                    .frame(width: padLeft - 4, alignment: .trailing)
                    .position(x: (padLeft - 4) / 2, y: midY)

                Text("-\(halfAmpStr)")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(.white.opacity(0.4))
                    .frame(width: padLeft - 4, alignment: .trailing)
                    .position(x: (padLeft - 4) / 2, y: padTop + plotH * 0.75)

                Text("-\(ampStr)")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(.white.opacity(0.4))
                    .frame(width: padLeft - 4, alignment: .trailing)
                    .position(x: (padLeft - 4) / 2, y: padTop + plotH * 0.925)

                ForEach(0...4, id: \.self) { i in
                    let t = windowSeconds * Double(i) / 4.0
                    let ms = t * 1000.0
                    let label = ms < 1.0
                        ? String(format: "%.2fms", ms)
                        : String(format: "%.1fms", ms)
                    let xPos = padLeft + plotW * Double(i) / 4.0
                    Text(label)
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundColor(.white.opacity(0.4))
                        .frame(width: 36, alignment: .center)
                        .position(x: xPos, y: padTop + plotH + padBottom * 0.6)
                }
            }
        }
    }
}
