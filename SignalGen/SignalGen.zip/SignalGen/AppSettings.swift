import SwiftUI
import Combine

class AppSettings: ObservableObject {
    @Published var showAdvancedUnits: Bool = false
    @Published var showGlow: Bool = false
    @Published var useCosine: Bool = false
}
